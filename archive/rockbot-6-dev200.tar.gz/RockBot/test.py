rock.sendtoserver("Privmsg " + to + " :This is test.py")
rock.sendtoserver("Privmsg " + to + " :The command was issued by " + nick)
rock.sendtoserver("Privmsg " + to + " :The command was issued to " + to)
rock.sendtoserver("Privmsg " + to + " :The Arguments are " + rest)
