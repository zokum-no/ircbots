/*  
 * conv.h
 *
 */

#include <stdio.h>
#include <time.h>

void converse( char *from, char *to, char *nick, char *rest );
