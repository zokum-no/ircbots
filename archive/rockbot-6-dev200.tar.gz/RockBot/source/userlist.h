#ifndef USERLIST_H
#define USERLIST_H

#include <time.h>
#include "config.h"
#include "channel.h"

char *gethandle(char *userhost, CHAN_list * ChanPtr);
void DelChanListUser(CHAN_list *ChanPtr, UserStruct *OpTarget);
int AddChanListAdditionalHost(CHAN_list *ChanPtr, UserStruct *UserPtr, char *userhost, int security);
UserStruct *AddChanListUser(CHAN_list * ChanPtr, char *userhost, char *handle, char *password, int level, int prot, int aop, int security, char *info);
int isowner(char *userhost);
FloodStruct *init_flood(void);
FloodStruct *find_flood(char *userhost);
int is_flooding(char *userhost);
int remove_floodstruct(FloodStruct *dummy);
void remove_oldfloods(void);
int add_flood(char *userhost);
char *shitchan( char *userhost);
ShitStruct *is_in_list2( char *thename);
UserStruct *FindOpByHandle(CHAN_list *ChanPtr, char *handle);
UserStruct *find_user( char *userhost, CHAN_list *ChanPtr);
ShitStruct *find_shit( char *userhost, CHAN_list *ChanPtr);
ShitStruct *find_shitbm( char *userhost);
MessagesStruct *init_messages();
MessagesStruct *get_message(MessagesStruct *mess, int num);
int add_message(MessagesStruct **mess, char *from, char *message, int num);
time_t getthetime( void );
int getseconds( time_t seconds);
int remove_all_from_userhostlist( void );
int update_userhostlist( char *thename, char *thechannel, time_t thetime);
UserHostStruct *init_userhostlist( void );
time_t getlasttime(char *fullname);
char *getlastchan(char *fullname);
char *getuserhost_fromlist(char *nick);
UserHostStruct *find_userhost(char *fullname);
int num_userhost(char *nick);
UserHostStruct *find_userhostfromnick(UserHostStruct *begin, char *nick);
int shitlevelbm( char *userhost, CHAN_list *ChanPtr);
int protlevelbm(char *userhost, CHAN_list *ChanPtr);
int remove_userhost( char *thename);
ListStruct *find_list(ListStruct *WhichList, char *thename);
int is_in_list( ListStruct *WhichList, char *thename);
ListStruct *init_list( void );
int add_to_list( ListStruct **WhichList, char *thename);
int remove_from_list( ListStruct **WhichList, char *thename );
int remove_all_from_list( ListStruct **WhichList );
int isuser( char *userhost, CHAN_list *ChanPtr );
int change_userlist( char *userhost, int level, int aop, int prot, CHAN_list *ChanPtr);
int change_shitlist( char *userhost, int level);
int change_a_list( char *userhost, int level, int aop, int prot);
int add_to_userlist( char *userhost, int level, int aop, int prot );
int add_to_shitlist( char *userhost, int level, char *channels);
int remove_from_userlist( char *userhost, CHAN_list *ChanPtr );
int remove_from_shitlist( char *userhost, CHAN_list *ChanPtr );
void show_shitlist( char *from, CHAN_list *ChanPtr, char *userhost );
void show_userlist( char *from, CHAN_list *ChanPtr, char *userhost );
void show_protlist( char *from, CHAN_list *ChanPtr, char *userhost );
int isauth(char *userhost, CHAN_list *ChanPtr);
int userlevel( char *userhost, CHAN_list *ChanPtr );
int isaop( char *userhost, CHAN_list *ChanPtr );
int protlevel( char *userhost, CHAN_list *ChanPtr );
int shitlevel( char *userhost, CHAN_list *ChanPtr );
int write_userlist( char *filename );
int write_shitlist( char *filename );

#endif /* USERLIST_H */



