#ifndef MEGAON
#define MEGAON

void    do_hotlink(char *from, char *to, char *rest);

#endif
