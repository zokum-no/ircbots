#ifndef BOTNET_H
#define BOTNET_H

int	on_botnet_command	(char *, char *, char *, char *, char *);
void	botnet_start		(char *);
void	check_botnet_server	(char *);
void	botnet_dcc_close	(char *);

#endif

