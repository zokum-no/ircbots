/*
 * send.c send stuff to the server, but not the basic stuff,
 *        more specified, like sendprivmsg, sendmode etc...
 *
 */

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>

#include "dcc.h"
#include "misc.h"
#include "config.h"

/*
 * sendprivmsg
 * Basically the same as send_to_server, just a little more easy to use
 *
 */
int sendprivmsg(char *sendto, char *format, ...)
{
   char entiremessage[WAYTOBIG];
   va_list args;


   memset(entiremessage, '\0', WAYTOBIG);
   va_start(args, format);
   vsnprintf(entiremessage, WAYTOBIG-1, format, args);
   va_end(args);
   return(send_to_server("PRIVMSG %s :%s", sendto, entiremessage));
}

void sendwelcome(char *welcome, char *nick, char *to)
{
   char sendbuf[MAXLEN], Welcome[MAXLEN];
   char *tmpbuf;
   int i, h, j;
   
   char buf1[MAXLEN], buf2[MAXLEN];

   /* Protect our string from nullification */
   strcpy(Welcome, welcome);

   if(tmpbuf = strtok(Welcome, "$"))
     strcpy(buf1, tmpbuf);
   else
     strcpy(buf1, "");
   if(tmpbuf = strtok(NULL, "\n\0"))
     strcpy(buf2, tmpbuf);
   else
     strcpy(buf2, "");
   if(!buf1)
   {
     Debug(DBGERROR, "No welcome string!");
     return;
   }
   sendprivmsg(to, "%s%s%s", buf1, nick, buf2?buf2:"" );
}

int sendnotice(char *sendto, char *format, ...)
{
  char entiremessage[WAYTOBIG];
  va_list args;

  memset(entiremessage, '\0', WAYTOBIG);
  va_start(args, format);
  vsnprintf(entiremessage, WAYTOBIG-1, format, args);
  va_end(args);

  return (send_to_server("NOTICE %s :%s", sendto, entiremessage));
}

int sendregister(char *nick, char *login, char *ircname)
{
  if (!send_to_server("USER %s blah.host blah :%s", login, ircname))
    return FAIL;
  sendnick(nick);
}

int sendping(char *to)
{
  return (send_to_server("PING %s", to));
}

int sendnick(char *nick)
{
  return (send_to_server("NICK %s", nick));
}

int sendjoin(char *channel, char *key)
{
  return (send_to_server("JOIN %s %s", channel, key));
}

int sendpart(char *channel)
{
  return (send_to_server("PART %s", channel));
}

int sendquit(char *reason)
{
  int tmpret;

  tmpret = send_to_server("QUIT :%s\n", reason);
  sleep(5);
  return (tmpret);
}

int sendmode(char *to, char *format, ...)
{
  char buf[MAXLEN];
  va_list args;

  memset(buf, '\0', MAXLEN);
  va_start(args, format);
  vsnprintf(buf, MAXLEN-1, format, args);
  va_end(args);
  return(send_to_server("MODE %s %s", to, buf));
}

int sendkick(char *channel, char *nick, char *reason)
{
  char buf[MAXLEN];

  if (!reason || !*reason)
    sprintf(buf, "Later %s", nick);
  else
    strcpy(buf, reason);
  return (send_to_server("KICK %s %s :%s", channel, nick, buf));
}

int send_ctcp_reply(char *to, char *format, ...)
{
  char buf[MAXLEN];
  va_list args;

  memset(buf, '\0', MAXLEN);
  va_start(args, format);
  vsnprintf(buf, MAXLEN-1, format, args);
  va_end(args);

  return (send_to_server("NOTICE %s :\001%s\001", to, buf));
}

int send_ctcp(char *to, char *format, ...)
{
  char buf[MAXLEN];
  va_list args;

  memset(buf, '\0', MAXLEN);
  va_start(args, format);
  vsnprintf(buf, MAXLEN, format, args);
  va_end(args);
  return(send_to_server("PRIVMSG %s :\x01%s\x01", to, buf));
}

int sendison(char *nick)
{
  return (send_to_server("ISON %s", nick));
}

int senduserhost(char *nick)
{
  return (send_to_server("USERHOST %s", nick));
}

int send_to_user(char *sendto, char *format, ...)
{
  char entiremessage[WAYTOBIG];
  va_list args;
  int bytessend;

  memset(entiremessage, '\0', WAYTOBIG);
  va_start(args, format);
  vsnprintf(entiremessage, WAYTOBIG-1, format, args);
  va_end(args);

  if(strchr(entiremessage, '\n'))
    *strchr(entiremessage, '\n') = ' ';  /* Convert multiple lines to one for irc.. */
  if(!send_chat(sendto, entiremessage))  /* Try to send via dcc.. if no link, send it as NOTICE */
    return(sendnotice(getnick(sendto), "%s", entiremessage));
  else
    return (TRUE);
  return(TRUE);
}
