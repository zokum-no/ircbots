void do_math(char *from, char *target, char *math);
