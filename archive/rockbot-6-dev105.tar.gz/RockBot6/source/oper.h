/*
 *   oper.h
 */

#include <stdio.h>

void send_oper(char *nick, char *pass);
void do_oper(char *from, char *to, char *rest);
void do_kill(char *from, char *to, char *rest);

