#include <stdio.h>
#include <sys/types.h>
#include <sys/time.h>
#include <strings.h>
#include <string.h>
#include "channel.h"
#include "config.h"

typedef struct	server_struct
{
	char	servername[MAXLEN];
	int	serverport;
} serv_struc;

typedef	struct	rockbot_struct
{
	char		nick[MAXNICKLEN];
	char		ircname[MAXLEN];
	char		login[MAXLEN];
	char		channel[MAXLEN];
        SERVER_list     *servers;
        SERVER_list     *CurrentServer;
	int		current;
	int		server_sock;
/*
 * Should the channel list be in here with all the
 * userlists and things hanging off of that? Will we
 * ever want to run 2 bots from one process? good question.. -Rubin
 * To add:
 * - Channellist
 * - DCC list
 */
}	RockBotStruct;	

void AddServer(char *server, unsigned short int port, char *pass);


