#ifndef _LOG_H_
#define _LOG_H_

extern	void 	botlog( char *logfile, char *logfmt, ...);
extern	void 	globallog( char *logfile, char *logfmt, ...);

#endif
