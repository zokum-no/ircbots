void do_togseen(char *from, char *to, char *rest);
void do_togpub(char *from, char *to, char *rest);
void do_togaop(char *from, char *to, char *rest);
void do_togshit(char *from, char *to, char *rest);
void do_togenfm(char *from, char *to, char *rest);
void do_togflood( char *from, char *to, char *rest);
void do_togmass(char *from, char *to, char *rest);
void do_togik(char *from, char *to, char *rest);
void do_togprot(char *from, char *to, char *rest);
void do_togsd(char *from, char *to, char *rest);
void do_togwm(char *from, char *to, char *rest);
void do_togso( char *from, char *to, char *rest );
void do_togcc( char *from, char *to, char *rest );
void do_toglog( char *from, char *to, char *rest);
void do_toglogk( char *from, char *to, char *rest);
void do_togmuk(char *from, char *to, char *rest);
void do_toglogpm(char *from, char *to, char *rest);
void do_togbk(char *from, char *to, char *rest);



