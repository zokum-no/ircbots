void do_setfl(char *from, char *to, char *rest);
void do_setmol(char *from, char *to, char *rest);
void do_setmdol(char *from, char *to, char *rest);
void do_setmbl(char *from, char *to, char *rest);
void do_setmubl(char *from, char *to, char *rest);
void do_setikl(char *from, char *to, char *rest);
void do_setmass(char *from, char *to, char *rest);
void do_setksl(char *from, char *to, char *rest);
void do_setmal(char *from, char *to, char *rest);
void do_setmpl(char *from, char *to, char *rest);
void do_setsbt(char *from, char *to, char *rest);
void do_setmul(char *from, char *to, char *rest);


